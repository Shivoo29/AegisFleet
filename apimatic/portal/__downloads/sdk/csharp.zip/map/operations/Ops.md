<!-- Generated file — do not edit; regenerated with the SDK. -->

# Ops — operations

Accessor: `client.Ops` · Source: `src/AegisFleet/Api/Ops.cs` · 1 operation

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### Healthz

- **Signature**: `Healthz(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `object`
- **Error**: `ApiException<RawError>` — **Case B**

