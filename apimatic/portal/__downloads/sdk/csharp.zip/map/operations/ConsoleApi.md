<!-- Generated file — do not edit; regenerated with the SDK. -->

# ConsoleApi — operations

Accessor: `client.ConsoleApi` · Source: `src/AegisFleet/Api/ConsoleApi.cs` · 17 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### Approvals

- **Auth**: `options.HttpBasic`
- **Signature**: `Approvals(ApprovalsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Query params (wire ← C#)**: `status` ← `Status`
- **Returns**: `IReadOnlyList<Approval>`
- **Error**: `ApiException<ApprovalsError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `ApprovalsRequest` | `src/AegisFleet/Requests/ConsoleApi/ApprovalsRequest.cs` |
| `Approval` | `src/AegisFleet/Models/Approval.cs` |
| `ApprovalsError` | `src/AegisFleet/Errors/ApprovalsError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### DecideApproval

- **Auth**: `options.HttpBasic`
- **Signature**: `DecideApproval(DecideApprovalRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `ApprovalId`, `Action`
- **Returns**: `ApprovalResult`
- **Error**: `ApiException<DecideApprovalError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `DecideApprovalRequest` | `src/AegisFleet/Requests/ConsoleApi/DecideApprovalRequest.cs` |
| `ActionEnum` | `src/AegisFleet/Models/Enums/ActionEnum.cs` |
| `Body1` | `src/AegisFleet/Models/AnyOf/Body1.cs` |
| `ApprovalResult` | `src/AegisFleet/Models/ApprovalResult.cs` |
| `DecideApprovalError` | `src/AegisFleet/Errors/DecideApprovalError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### DisputeDetail

- **Auth**: `options.HttpBasic`
- **Signature**: `DisputeDetail(DisputeDetailRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `DisputeId`
- **Returns**: `DisputeDetail`
- **Error**: `ApiException<DisputeDetailError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401, 404] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `DisputeDetailRequest` | `src/AegisFleet/Requests/ConsoleApi/DisputeDetailRequest.cs` |
| `DisputeDetail` | `src/AegisFleet/Models/DisputeDetail.cs` |
| `DisputeDetailError` | `src/AegisFleet/Errors/DisputeDetailError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### Disputes

- **Auth**: `options.HttpBasic`
- **Signature**: `Disputes(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `IReadOnlyList<Dispute>`
- **Error**: `ApiException<DisputesError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `Dispute` | `src/AegisFleet/Models/Dispute.cs` |
| `DisputesError` | `src/AegisFleet/Errors/DisputesError.cs` |

### GetKillswitch

- **Auth**: `options.HttpBasic`
- **Signature**: `GetKillswitch(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `KillSwitch`
- **Error**: `ApiException<GetKillswitchError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `KillSwitch` | `src/AegisFleet/Models/KillSwitch.cs` |
| `GetKillswitchError` | `src/AegisFleet/Errors/GetKillswitchError.cs` |

### Health

- **Auth**: `options.HttpBasic`
- **Signature**: `Health(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `Health`
- **Error**: `ApiException<HealthError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `Health` | `src/AegisFleet/Models/Health.cs` |
| `HealthError` | `src/AegisFleet/Errors/HealthError.cs` |

### Inbox

- **Auth**: `options.HttpBasic`
- **Signature**: `Inbox(InboxRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `InboxVerdict`
- **Error**: `ApiException<InboxError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `InboxRequest` | `src/AegisFleet/Requests/ConsoleApi/InboxRequest.cs` |
| `InboxEmail` | `src/AegisFleet/Models/InboxEmail.cs` |
| `InboxVerdict` | `src/AegisFleet/Models/InboxVerdict.cs` |
| `InboxError` | `src/AegisFleet/Errors/InboxError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### Invoices

- **Auth**: `options.HttpBasic`
- **Signature**: `Invoices(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `IReadOnlyList<Invoice>`
- **Error**: `ApiException<InvoicesError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `Invoice` | `src/AegisFleet/Models/Invoice.cs` |
| `InvoicesError` | `src/AegisFleet/Errors/InvoicesError.cs` |

### Ledger

- **Auth**: `options.HttpBasic`
- **Signature**: `Ledger(LedgerRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Query params (wire ← C#)**: `kind` ← `Kind`, `subject_id` ← `SubjectId`, `limit` ← `Limit`
- **Returns**: `IReadOnlyList<LedgerEntry>`
- **Error**: `ApiException<LedgerError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `LedgerRequest` | `src/AegisFleet/Requests/ConsoleApi/LedgerRequest.cs` |
| `Kind1` | `src/AegisFleet/Models/AnyOf/Kind1.cs` |
| `SubjectIdModel` | `src/AegisFleet/Models/AnyOf/SubjectIdModel.cs` |
| `LedgerEntry` | `src/AegisFleet/Models/LedgerEntry.cs` |
| `LedgerError` | `src/AegisFleet/Errors/LedgerError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### LedgerVerify

- **Auth**: `options.HttpBasic`
- **Signature**: `LedgerVerify(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `ChainVerify`
- **Error**: `ApiException<LedgerVerifyError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `ChainVerify` | `src/AegisFleet/Models/ChainVerify.cs` |
| `LedgerVerifyError` | `src/AegisFleet/Errors/LedgerVerifyError.cs` |

### Login

- **Signature**: `Login(LoginRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `Me`
- **Error**: `ApiException<LoginError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `LoginRequest` | `src/AegisFleet/Requests/ConsoleApi/LoginRequest.cs` |
| `LoginBody` | `src/AegisFleet/Models/LoginBody.cs` |
| `Me` | `src/AegisFleet/Models/Me.cs` |
| `LoginError` | `src/AegisFleet/Errors/LoginError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### Logout

- **Signature**: `Logout(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `Ok`
- **Error**: `ApiException<LogoutError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `Ok` | `src/AegisFleet/Models/Ok.cs` |
| `LogoutError` | `src/AegisFleet/Errors/LogoutError.cs` |

### Me

- **Auth**: `options.HttpBasic`
- **Signature**: `Me(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `Me`
- **Error**: `ApiException<MeError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `Me` | `src/AegisFleet/Models/Me.cs` |
| `MeError` | `src/AegisFleet/Errors/MeError.cs` |

### PostKillswitch

- **Auth**: `options.HttpBasic`
- **Signature**: `PostKillswitch(PostKillswitchRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `KillSwitch`
- **Error**: `ApiException<PostKillswitchError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `PostKillswitchRequest` | `src/AegisFleet/Requests/ConsoleApi/PostKillswitchRequest.cs` |
| `KillSwitchBody` | `src/AegisFleet/Models/KillSwitchBody.cs` |
| `KillSwitch` | `src/AegisFleet/Models/KillSwitch.cs` |
| `PostKillswitchError` | `src/AegisFleet/Errors/PostKillswitchError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### Runs

- **Auth**: `options.HttpBasic`
- **Signature**: `Runs(RunsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Query params (wire ← C#)**: `limit` ← `Limit`
- **Returns**: `IReadOnlyList<AgentRun>`
- **Error**: `ApiException<RunsError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `RunsRequest` | `src/AegisFleet/Requests/ConsoleApi/RunsRequest.cs` |
| `AgentRun` | `src/AegisFleet/Models/AgentRun.cs` |
| `RunsError` | `src/AegisFleet/Errors/RunsError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### Shipments

- **Auth**: `options.HttpBasic`
- **Signature**: `Shipments(ShipmentsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `ShipmentResult`
- **Error**: `ApiException<ShipmentsError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value)` [422] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `ShipmentsRequest` | `src/AegisFleet/Requests/ConsoleApi/ShipmentsRequest.cs` |
| `ShipmentBody` | `src/AegisFleet/Models/ShipmentBody.cs` |
| `ShipmentResult` | `src/AegisFleet/Models/ShipmentResult.cs` |
| `ShipmentsError` | `src/AegisFleet/Errors/ShipmentsError.cs` |
| `HttpValidationError` | `src/AegisFleet/Models/HttpValidationError.cs` |

### Summary

- **Auth**: `options.HttpBasic`
- **Signature**: `Summary(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `Summary`
- **Error**: `ApiException<SummaryError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent([NotNullWhen(true)] out RawError? value)` [401] · `TryGetRawError([NotNullWhen(true)] out RawError? error)` [fallback]

| Type | Source |
| --- | --- |
| `Summary` | `src/AegisFleet/Models/Summary.cs` |
| `SummaryError` | `src/AegisFleet/Errors/SummaryError.cs` |

