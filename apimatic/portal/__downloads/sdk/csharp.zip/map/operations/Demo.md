<!-- Generated file — do not edit; regenerated with the SDK. -->

# Demo — operations

Accessor: `client.Demo` · Source: `src/AegisFleet/Api/Demo.cs` · 9 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### Delivered

- **Auth**: `options.HttpBasic`
- **Signature**: `Delivered(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

### DemoStatus

- **Auth**: `options.HttpBasic`
- **Signature**: `DemoStatus(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `object`
- **Error**: `ApiException<RawError>` — **Case B**

### Overdue

- **Auth**: `options.HttpBasic`
- **Signature**: `Overdue(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

### ReplayInjection

- **Auth**: `options.HttpBasic`
- **Signature**: `ReplayInjection(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

### Reset

- **Auth**: `options.HttpBasic`
- **Signature**: `Reset(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

### SandboxInvoice

- **Auth**: `options.HttpBasic`
- **Signature**: `SandboxInvoice(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

### SandboxRecordPayment

- **Auth**: `options.HttpBasic`
- **Signature**: `SandboxRecordPayment(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

### ScamEmail

- **Auth**: `options.HttpBasic`
- **Signature**: `ScamEmail(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

### Tamper

- **Auth**: `options.HttpBasic`
- **Signature**: `Tamper(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `DemoResult`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `DemoResult` | `src/AegisFleet/Models/DemoResult.cs` |

