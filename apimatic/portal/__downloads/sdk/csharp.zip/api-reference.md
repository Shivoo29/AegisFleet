# Reference

Every operation below is shown in its throwing form. On an error status it throws `ApiException<TError>` — the status code, headers, content type and the operation's error type, `RawError` (the raw body) when the spec declares none — and where an operation offers an `…AsResult` sibling, that sibling returns `ApiResult<TResponse, TError>` instead. A request that produces no usable response surfaces as `SdkConnectionException` or `SdkTimeoutException`, a body that does not match the documented response type as `ResponseDeserializationException`, and a required credential that is not configured, or one that cannot be applied, as `AuthSchemeException`; all of them derive from `SdkException` and name the failed call. See [README → Error Handling](README.md#error-handling).

> Source: [AegisFleetClient](src/AegisFleet/AegisFleetClient.cs)

## ConsoleApi

> Source: [ConsoleApi](src/AegisFleet/Api/ConsoleApi.cs)

<details>
<summary><code>Task&lt;IReadOnlyList&lt;Approval&gt;&gt; Approvals(ApprovalsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Agent actions the gateway held for a human decision (over the money cap).

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Approvals(new ApprovalsRequest());
    // TODO: Handle 'response' of type IReadOnlyList<Approval>
}
catch (ApiException<ApprovalsError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[ApprovalsRequest](src/AegisFleet/Requests/ConsoleApi/ApprovalsRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>IReadOnlyList&lt;[Approval](src/AegisFleet/Models/Approval.cs)&gt;</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[ApprovalsError](src/AegisFleet/Errors/ApprovalsError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;ApprovalResult&gt; DecideApproval(DecideApprovalRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Approve (the gateway then executes the held action) or reject it. Both are sealed.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.DecideApproval(new DecideApprovalRequest
    {
        ApprovalId = "some example string",
        Action = ActionEnum.Approve,
    });
    // TODO: Handle 'response' of type ApprovalResult
}
catch (ApiException<DecideApprovalError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[DecideApprovalRequest](src/AegisFleet/Requests/ConsoleApi/DecideApprovalRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApprovalResult](src/AegisFleet/Models/ApprovalResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[DecideApprovalError](src/AegisFleet/Errors/DecideApprovalError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DisputeDetail&gt; DisputeDetail(DisputeDetailRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

One dispute with Defender's evidence pack and the pending approval to submit it.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.DisputeDetail(new DisputeDetailRequest
    {
        DisputeId = "some example string",
    });
    // TODO: Handle 'response' of type DisputeDetail
}
catch (ApiException<DisputeDetailError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[DisputeDetailRequest](src/AegisFleet/Requests/ConsoleApi/DisputeDetailRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DisputeDetail](src/AegisFleet/Models/DisputeDetail.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[DisputeDetailError](src/AegisFleet/Errors/DisputeDetailError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;IReadOnlyList&lt;Dispute&gt;&gt; Disputes(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Latest state of every PayPal dispute, newest first.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Disputes();
    // TODO: Handle 'response' of type IReadOnlyList<Dispute>
}
catch (ApiException<DisputesError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>IReadOnlyList&lt;[Dispute](src/AegisFleet/Models/Dispute.cs)&gt;</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[DisputesError](src/AegisFleet/Errors/DisputesError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;KillSwitch&gt; GetKillswitch(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Is the kill switch on?

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.GetKillswitch();
    // TODO: Handle 'response' of type KillSwitch
}
catch (ApiException<GetKillswitchError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[KillSwitch](src/AegisFleet/Models/KillSwitch.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[GetKillswitchError](src/AegisFleet/Errors/GetKillswitchError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Health&gt; Health(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Score and factors are recomputed from the ledger on every call, so a dispute that
arrived after Guardian's last run still counts. Guardian's AI recommendations are
reused only while the factors they were written for still hold.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Health();
    // TODO: Handle 'response' of type Health
}
catch (ApiException<HealthError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Health](src/AegisFleet/Models/Health.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[HealthError](src/AegisFleet/Errors/HealthError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;InboxVerdict&gt; Inbox(InboxRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Run Sentinel inline (a few seconds) so the console gets the verdict in one call.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Inbox(new InboxRequest { Body = new InboxEmail() });
    // TODO: Handle 'response' of type InboxVerdict
}
catch (ApiException<InboxError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[InboxRequest](src/AegisFleet/Requests/ConsoleApi/InboxRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[InboxVerdict](src/AegisFleet/Models/InboxVerdict.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[InboxError](src/AegisFleet/Errors/InboxError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;IReadOnlyList&lt;Invoice&gt;&gt; Invoices(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Invoices with paid/overdue status, risk, shipment and PayPal payment link.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Invoices();
    // TODO: Handle 'response' of type IReadOnlyList<Invoice>
}
catch (ApiException<InvoicesError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>IReadOnlyList&lt;[Invoice](src/AegisFleet/Models/Invoice.cs)&gt;</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[InvoicesError](src/AegisFleet/Errors/InvoicesError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;IReadOnlyList&lt;LedgerEntry&gt;&gt; Ledger(LedgerRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Proof Ledger entries, newest first. Each entry's hash covers the previous one.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Ledger(new LedgerRequest());
    // TODO: Handle 'response' of type IReadOnlyList<LedgerEntry>
}
catch (ApiException<LedgerError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[LedgerRequest](src/AegisFleet/Requests/ConsoleApi/LedgerRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>IReadOnlyList&lt;[LedgerEntry](src/AegisFleet/Models/LedgerEntry.cs)&gt;</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[LedgerError](src/AegisFleet/Errors/LedgerError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;ChainVerify&gt; LedgerVerify(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Recompute every hash in the chain and report the first entry that no longer matches.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.LedgerVerify();
    // TODO: Handle 'response' of type ChainVerify
}
catch (ApiException<LedgerVerifyError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ChainVerify](src/AegisFleet/Models/ChainVerify.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[LedgerVerifyError](src/AegisFleet/Errors/LedgerVerifyError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Me&gt; Login(LoginRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Check a username and password and set a 12-hour session cookie.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Login(new LoginRequest { Body = new LoginBody() });
    // TODO: Handle 'response' of type Me
}
catch (ApiException<LoginError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[LoginRequest](src/AegisFleet/Requests/ConsoleApi/LoginRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Me](src/AegisFleet/Models/Me.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[LoginError](src/AegisFleet/Errors/LoginError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Ok&gt; Logout(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Clear the session cookie.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Logout();
    // TODO: Handle 'response' of type Ok
}
catch (ApiException<LogoutError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Ok](src/AegisFleet/Models/Ok.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[LogoutError](src/AegisFleet/Errors/LogoutError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Me&gt; Me(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Who is logged in, and whether they are the seller (dev) or a read-mostly judge.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Me();
    // TODO: Handle 'response' of type Me
}
catch (ApiException<MeError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Me](src/AegisFleet/Models/Me.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[MeError](src/AegisFleet/Errors/MeError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;KillSwitch&gt; PostKillswitch(PostKillswitchRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Turn the kill switch on or off. While on, the gateway denies every agent action.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.PostKillswitch(new PostKillswitchRequest { Body = new KillSwitchBody() });
    // TODO: Handle 'response' of type KillSwitch
}
catch (ApiException<PostKillswitchError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PostKillswitchRequest](src/AegisFleet/Requests/ConsoleApi/PostKillswitchRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[KillSwitch](src/AegisFleet/Models/KillSwitch.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[PostKillswitchError](src/AegisFleet/Errors/PostKillswitchError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;IReadOnlyList&lt;AgentRun&gt;&gt; Runs(RunsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Recent agent runs with their steps and structured output.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Runs(new RunsRequest());
    // TODO: Handle 'response' of type IReadOnlyList<AgentRun>
}
catch (ApiException<RunsError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[RunsRequest](src/AegisFleet/Requests/ConsoleApi/RunsRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>IReadOnlyList&lt;[AgentRun](src/AegisFleet/Models/AgentRun.cs)&gt;</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RunsError](src/AegisFleet/Errors/RunsError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;ShipmentResult&gt; Shipments(ShipmentsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Seller adds tracking: store it, then fire shipment.created (sealed + routed to Guardian).

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Shipments(new ShipmentsRequest { Body = new ShipmentBody() });
    // TODO: Handle 'response' of type ShipmentResult
}
catch (ApiException<ShipmentsError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[ShipmentsRequest](src/AegisFleet/Requests/ConsoleApi/ShipmentsRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ShipmentResult](src/AegisFleet/Models/ShipmentResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[ShipmentsError](src/AegisFleet/Errors/ShipmentsError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Summary&gt; Summary(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Overview numbers: money waiting on approval, open disputes, overdue invoices, health, chain state.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.ConsoleApi.Summary();
    // TODO: Handle 'response' of type Summary
}
catch (ApiException<SummaryError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Summary](src/AegisFleet/Models/Summary.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[SummaryError](src/AegisFleet/Errors/SummaryError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Demo

> Source: [Demo](src/AegisFleet/Api/Demo.cs)

<details>
<summary><code>Task&lt;DemoResult&gt; Delivered(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Courier says the parcel arrived -> Guardian updates tracking.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.Delivered();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;object&gt; DemoStatus(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

200 when demo mode is on (404 otherwise).

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.DemoStatus();
    // TODO: Handle 'response' of type object
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DemoResult&gt; Overdue(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

INV-0006 slips 9 days past due -> Collector scores it and sends a capped, polite reminder.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.Overdue();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DemoResult&gt; ReplayInjection(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

An email told an agent to refund. Sentinel isn't allowed to refund -> gateway DENY, sealed.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.ReplayInjection();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DemoResult&gt; Reset(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Wipe everything, then replay Riya's story so the console never starts empty.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.Reset();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DemoResult&gt; SandboxInvoice(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Create a real invoice in the PayPal sandbox. Paying it fires a real, signed webhook.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.SandboxInvoice();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DemoResult&gt; SandboxRecordPayment(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Backup for flaky sandbox checkout: record payment on the newest unpaid sandbox invoice.

PayPal then sends the same signed INVOICING.INVOICE.PAID webhook a buyer payment would.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.SandboxRecordPayment();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DemoResult&gt; ScamEmail(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Fake 'payment received' email: no verified payment in the ledger -> Sentinel says scam.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.ScamEmail();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;DemoResult&gt; Tamper(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Edit one sealed entry behind the ledger's back -> verify() points at it.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Demo.Tamper();
    // TODO: Handle 'response' of type DemoResult
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DemoResult](src/AegisFleet/Models/DemoResult.cs)</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Ops

> Source: [Ops](src/AegisFleet/Api/Ops.cs)

<details>
<summary><code>Task&lt;object&gt; Healthz(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Liveness probe for Render and the keep-alive ping. No auth.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Ops.Healthz();
    // TODO: Handle 'response' of type object
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## WebhooksApi

> Source: [WebhooksApi](src/AegisFleet/Api/WebhooksApi.cs)

<details>
<summary><code>Task&lt;object&gt; PaypalWebhook(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

PayPal calls this. The signature is verified with PayPal before the event is sealed and routed.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.WebhooksApi.PaypalWebhook();
    // TODO: Handle 'response' of type object
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/AegisFleet/Core/Exceptions/ApiException.cs)&lt;[RawError](src/AegisFleet/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

