using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// AgentRun object
/// </summary>
public record AgentRun
{
    /// <summary>
    /// Unique id
    /// </summary>
    [JsonPropertyName("id")]
    public required string Id { get; init; }

    /// <summary>
    /// Agent name: sentinel, defender, guardian or collector
    /// </summary>
    [JsonPropertyName("agent")]
    public required string Agent { get; init; }

    /// <summary>
    /// Event that started the run, e.g. dispute.created
    /// </summary>
    [JsonPropertyName("event_type")]
    public required string EventType { get; init; }

    /// <summary>
    /// Current status
    /// </summary>
    [JsonPropertyName("status")]
    public required string Status { get; init; }

    /// <summary>
    /// Each step the agent took
    /// </summary>
    [JsonPropertyName("steps")]
    public required IReadOnlyList<object> Steps { get; init; }

    /// <summary>
    /// Agent's structured result
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("output")]
    public Output? Output { get; init; }

    /// <summary>
    /// When the run started (ISO 8601)
    /// </summary>
    [JsonPropertyName("started_at")]
    public required DateTimeOffset StartedAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
