using System;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using System.Text.Json.Serialization;
using AegisFleet.Core.Extensions;
using AegisFleet.Core.Models;

namespace AegisFleet.Models.AnyOf;

[JsonConverter(typeof(Body1Converter))]
public record Body1
{
    private readonly Optional<ApprovalBody> _approvalBodyValue;

    private readonly Optional<UnknownArm> _unknownValue;

    private Body1(Optional<ApprovalBody> approvalBodyValue, Optional<UnknownArm> unknownValue)
    {
        _approvalBodyValue = approvalBodyValue;
        _unknownValue = unknownValue;
    }

    public static Body1 ApprovalBody(ApprovalBody value) => new(Optional<ApprovalBody>.Some(value), default);

    internal static Body1 Unknown(JsonElement value) => new(default, Optional<UnknownArm>.Some(new UnknownArm(value)));

    public bool TryGetApprovalBody([NotNullWhen(true)] out ApprovalBody? value) =>
        _approvalBodyValue.TryGetValue(out value);

    public bool TryGetUnknown(out JsonElement value) => _unknownValue.TryGetValue(out value);

    public static implicit operator Body1(ApprovalBody value) => ApprovalBody(value);

    public TResult Match<TResult>(Func<ApprovalBody, TResult> onApprovalBody, Func<JsonElement, TResult> otherwise) =>
        this switch
        {
            _ when TryGetApprovalBody(out var approvalBodyValue) => onApprovalBody(approvalBodyValue),
            _ when TryGetUnknown(out var unknownValue) => otherwise(unknownValue),
            _ => throw new InvalidOperationException($"{nameof(Body1)} holds no value.")
        };

    public void Match(Action<ApprovalBody> onApprovalBody, Action<JsonElement> otherwise)
    {
        if (TryGetApprovalBody(out var approvalBodyValue)) onApprovalBody(approvalBodyValue);
        else if (TryGetUnknown(out var unknownValue)) otherwise(unknownValue);
        else throw new InvalidOperationException($"{nameof(Body1)} holds no value.");
    }
}

file sealed class Body1Converter : JsonConverter<Body1>
{
    public override Body1 Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        using var doc = JsonDocument.ParseValue(ref reader);
        var root = doc.RootElement;
        if (JsonSerializer.TryDeserialize<ApprovalBody>(root, options, out var approvalBodyValue))
        {
            return Body1.ApprovalBody(approvalBodyValue);
        }
        return Body1.Unknown(root);
    }

    public override void Write(Utf8JsonWriter writer, Body1 value, JsonSerializerOptions options)
    {
        if (value.TryGetApprovalBody(out var approvalBodyValue))
        {
            JsonSerializer.Serialize(writer, approvalBodyValue, options);
        }
        else if (value.TryGetUnknown(out var unknownValue))
        {
            unknownValue.WriteTo(writer);
        }
        else
        {
            throw new JsonException($"{nameof(Body1)} contains no valid value to serialize.");
        }
    }
}
