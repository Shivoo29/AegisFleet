using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// approve or reject
/// </summary>
[JsonConverter(typeof(StringEnumConverter<ActionEnum>))]
public sealed record ActionEnum : OpenStringEnum<ActionEnum>
{
    private ActionEnum(string value) : base(value)
    {
    }

    public static readonly ActionEnum Approve = new("approve");

    public static readonly ActionEnum Reject = new("reject");

    public TResult Match<TResult>(Func<TResult> onApprove, Func<TResult> onReject, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Approve => onApprove(),
            _ when this == Reject => onReject(),
            _ => otherwise(Value)
        };

    public void Match(Action onApprove, Action onReject, Action<string> otherwise)
    {
        if (this == Approve) onApprove();
        else if (this == Reject) onReject();
        else otherwise(Value);
    }
}
