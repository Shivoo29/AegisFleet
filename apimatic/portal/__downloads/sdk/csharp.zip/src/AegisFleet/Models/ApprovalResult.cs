using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;
using AegisFleet.Models.Enums;

namespace AegisFleet.Models;

/// <summary>
/// ApprovalResult object
/// </summary>
public record ApprovalResult
{
    /// <summary>
    /// Current status
    /// </summary>
    [JsonPropertyName("status")]
    public required Status1 Status { get; init; }

    /// <summary>
    /// Gateway decision for the executed action
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("decision")]
    public Decision1? Decision { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
