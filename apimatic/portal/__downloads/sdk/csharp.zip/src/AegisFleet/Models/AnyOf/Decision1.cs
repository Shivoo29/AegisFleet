using System;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using System.Text.Json.Serialization;
using AegisFleet.Core.Extensions;
using AegisFleet.Core.Models;

namespace AegisFleet.Models.AnyOf;

/// <summary>
/// Gateway decision for the executed action
/// </summary>
[JsonConverter(typeof(Decision1Converter))]
public record Decision1
{
    private readonly Optional<Decision2> _decision2Value;

    private readonly Optional<UnknownArm> _unknownValue;

    private Decision1(Optional<Decision2> decision2Value, Optional<UnknownArm> unknownValue)
    {
        _decision2Value = decision2Value;
        _unknownValue = unknownValue;
    }

    public static Decision1 Decision2(Decision2 value) => new(Optional<Decision2>.Some(value), default);

    internal static Decision1 Unknown(JsonElement value) =>
        new(default, Optional<UnknownArm>.Some(new UnknownArm(value)));

    public bool TryGetDecision2([NotNullWhen(true)] out Decision2? value) => _decision2Value.TryGetValue(out value);

    public bool TryGetUnknown(out JsonElement value) => _unknownValue.TryGetValue(out value);

    public static implicit operator Decision1(Decision2 value) => Decision2(value);

    public TResult Match<TResult>(Func<Decision2, TResult> onDecision2, Func<JsonElement, TResult> otherwise) =>
        this switch
        {
            _ when TryGetDecision2(out var decision2Value) => onDecision2(decision2Value),
            _ when TryGetUnknown(out var unknownValue) => otherwise(unknownValue),
            _ => throw new InvalidOperationException($"{nameof(Decision1)} holds no value.")
        };

    public void Match(Action<Decision2> onDecision2, Action<JsonElement> otherwise)
    {
        if (TryGetDecision2(out var decision2Value)) onDecision2(decision2Value);
        else if (TryGetUnknown(out var unknownValue)) otherwise(unknownValue);
        else throw new InvalidOperationException($"{nameof(Decision1)} holds no value.");
    }
}

file sealed class Decision1Converter : JsonConverter<Decision1>
{
    public override Decision1 Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        using var doc = JsonDocument.ParseValue(ref reader);
        var root = doc.RootElement;
        if (JsonSerializer.TryDeserialize<Decision2>(root, options, out var decision2Value))
        {
            return Decision1.Decision2(decision2Value);
        }
        return Decision1.Unknown(root);
    }

    public override void Write(Utf8JsonWriter writer, Decision1 value, JsonSerializerOptions options)
    {
        if (value.TryGetDecision2(out var decision2Value))
        {
            JsonSerializer.Serialize(writer, decision2Value, options);
        }
        else if (value.TryGetUnknown(out var unknownValue))
        {
            unknownValue.WriteTo(writer);
        }
        else
        {
            throw new JsonException($"{nameof(Decision1)} contains no valid value to serialize.");
        }
    }
}
