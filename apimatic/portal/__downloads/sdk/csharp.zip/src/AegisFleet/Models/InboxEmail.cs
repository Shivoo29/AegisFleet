using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// InboxEmail object
/// </summary>
public record InboxEmail
{
    /// <summary>
    /// What this is about: an invoice, dispute or email id
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("subject_id")]
    public SubjectId? SubjectId { get; init; }

    /// <summary>
    /// Invoice id, e.g. INV-0007
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("invoice_id")]
    public InvoiceId? InvoiceId { get; init; }

    /// <summary>
    /// Sender address
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("from")]
    public From? From { get; init; }

    /// <summary>
    /// Email subject
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("subject")]
    public Subject? Subject { get; init; }

    /// <summary>
    /// Email body text
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("body")]
    public Body? Body { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
