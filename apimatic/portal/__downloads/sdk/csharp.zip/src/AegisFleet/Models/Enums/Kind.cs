using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// Entry kind: event, decision, agent_step, approval or note
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Kind>))]
public sealed record Kind : OpenStringEnum<Kind>
{
    private Kind(string value) : base(value)
    {
    }

    public static readonly Kind Event = new("event");

    public static readonly Kind Decision = new("decision");

    public static readonly Kind AgentStep = new("agent_step");

    public static readonly Kind Approval = new("approval");

    public static readonly Kind Note = new("note");

    public TResult Match<TResult>(Func<TResult> onEvent,
        Func<TResult> onDecision,
        Func<TResult> onAgentStep,
        Func<TResult> onApproval,
        Func<TResult> onNote,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Event => onEvent(),
            _ when this == Decision => onDecision(),
            _ when this == AgentStep => onAgentStep(),
            _ when this == Approval => onApproval(),
            _ when this == Note => onNote(),
            _ => otherwise(Value)
        };

    public void Match(Action onEvent,
        Action onDecision,
        Action onAgentStep,
        Action onApproval,
        Action onNote,
        Action<string> otherwise)
    {
        if (this == Event) onEvent();
        else if (this == Decision) onDecision();
        else if (this == AgentStep) onAgentStep();
        else if (this == Approval) onApproval();
        else if (this == Note) onNote();
        else otherwise(Value);
    }
}
