using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// ApprovalBody object
/// </summary>
public record ApprovalBody
{
    /// <summary>
    /// Optional reason, sealed into the ledger with the decision
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("note")]
    public string? Note { get; init; } = "";

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
