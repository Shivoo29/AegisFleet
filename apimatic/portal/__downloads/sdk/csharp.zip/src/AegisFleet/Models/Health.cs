using System.Collections.Generic;
using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// Health object
/// </summary>
public record Health
{
    /// <summary>
    /// Health score, 0-100
    /// </summary>
    [JsonPropertyName("score")]
    public required int Score { get; init; }

    /// <summary>
    /// What the health score is made of
    /// </summary>
    [JsonPropertyName("factors")]
    public required IReadOnlyList<HealthFactor> Factors { get; init; }

    /// <summary>
    /// Steps that would raise the score
    /// </summary>
    [JsonPropertyName("recommendations")]
    public required IReadOnlyList<string> Recommendations { get; init; }

    /// <summary>
    /// Draft appeal text Guardian wrote for PayPal, if the account is limited
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("appeal_pack")]
    public AppealPack? AppealPack { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
