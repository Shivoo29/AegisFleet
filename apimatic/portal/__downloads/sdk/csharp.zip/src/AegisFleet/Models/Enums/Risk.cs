using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// Payment risk: low, medium or high
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Risk>))]
public sealed record Risk : OpenStringEnum<Risk>
{
    private Risk(string value) : base(value)
    {
    }

    public static readonly Risk Low = new("low");

    public static readonly Risk Medium = new("medium");

    public static readonly Risk High = new("high");

    public TResult Match<TResult>(Func<TResult> onLow,
        Func<TResult> onMedium,
        Func<TResult> onHigh,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Low => onLow(),
            _ when this == Medium => onMedium(),
            _ when this == High => onHigh(),
            _ => otherwise(Value)
        };

    public void Match(Action onLow, Action onMedium, Action onHigh, Action<string> otherwise)
    {
        if (this == Low) onLow();
        else if (this == Medium) onMedium();
        else if (this == High) onHigh();
        else otherwise(Value);
    }
}
