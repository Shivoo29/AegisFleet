using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// allow, hold or deny
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Outcome>))]
public sealed record Outcome : OpenStringEnum<Outcome>
{
    private Outcome(string value) : base(value)
    {
    }

    public static readonly Outcome Allow = new("allow");

    public static readonly Outcome Hold = new("hold");

    public static readonly Outcome Deny = new("deny");

    public TResult Match<TResult>(Func<TResult> onAllow,
        Func<TResult> onHold,
        Func<TResult> onDeny,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Allow => onAllow(),
            _ when this == Hold => onHold(),
            _ when this == Deny => onDeny(),
            _ => otherwise(Value)
        };

    public void Match(Action onAllow, Action onHold, Action onDeny, Action<string> otherwise)
    {
        if (this == Allow) onAllow();
        else if (this == Hold) onHold();
        else if (this == Deny) onDeny();
        else otherwise(Value);
    }
}
