using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;
using AegisFleet.Models.Enums;

namespace AegisFleet.Models;

/// <summary>
/// Invoice object
/// </summary>
public record Invoice
{
    /// <summary>
    /// Unique id
    /// </summary>
    [JsonPropertyName("id")]
    public required string Id { get; init; }

    /// <summary>
    /// Buyer's email address
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("buyer_email")]
    public BuyerEmail? BuyerEmail { get; init; }

    /// <summary>
    /// Amount in minor units (cents)
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("amount_cents")]
    public AmountCents? AmountCents { get; init; }

    /// <summary>
    /// ISO 4217 currency code
    /// </summary>
    [JsonPropertyName("currency")]
    public required string Currency { get; init; }

    /// <summary>
    /// Current status
    /// </summary>
    [JsonPropertyName("status")]
    public required Status2 Status { get; init; }

    /// <summary>
    /// Days past the due date; 0 when paid or not yet due
    /// </summary>
    [JsonPropertyName("days_overdue")]
    public required int DaysOverdue { get; init; }

    /// <summary>
    /// Payment risk: low, medium or high
    /// </summary>
    [JsonPropertyName("risk")]
    public required Risk Risk { get; init; }

    /// <summary>
    /// True when tracking was added
    /// </summary>
    [JsonPropertyName("shipped")]
    public required bool Shipped { get; init; }

    /// <summary>
    /// Carrier tracking number
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("tracking_number")]
    public TrackingNumber? TrackingNumber { get; init; }

    /// <summary>
    /// When it was created (ISO 8601)
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("created_at")]
    public CreatedAt? CreatedAt { get; init; }

    /// <summary>
    /// When payment was verified (ISO 8601)
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("paid_at")]
    public PaidAt? PaidAt { get; init; }

    /// <summary>
    /// PayPal payment page for this invoice
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("pay_url")]
    public PayUrl? PayUrl { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
