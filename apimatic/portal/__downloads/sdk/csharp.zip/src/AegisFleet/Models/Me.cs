using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.Enums;

namespace AegisFleet.Models;

/// <summary>
/// Me object
/// </summary>
public record Me
{
    /// <summary>
    /// Logged-in user name
    /// </summary>
    [JsonPropertyName("user")]
    public required string User { get; init; }

    /// <summary>
    /// dev (seller) or judge
    /// </summary>
    [JsonPropertyName("role")]
    public required Role Role { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
