using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// PlanMove object
/// </summary>
public record PlanMove
{
    /// <summary>
    /// New time to run it (ISO 8601)
    /// </summary>
    [JsonPropertyName("due_at")]
    public required DateTimeOffset DueAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
