using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// DisputeDetail object
/// </summary>
public record DisputeDetail
{
    /// <summary>
    /// The dispute
    /// </summary>
    [JsonPropertyName("dispute")]
    public required Dispute1 Dispute { get; init; }

    /// <summary>
    /// Defender's evidence pack, every fact citing a ledger id
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("evidence_pack")]
    public EvidencePack? EvidencePack { get; init; }

    /// <summary>
    /// Id of the pending approval for this action
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("approval_id")]
    public ApprovalId? ApprovalId { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
