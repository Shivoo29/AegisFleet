using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// Ok object
/// </summary>
public record Ok
{
    /// <summary>
    /// True on success
    /// </summary>
    [JsonPropertyName("ok")]
    public required bool OkValue { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
