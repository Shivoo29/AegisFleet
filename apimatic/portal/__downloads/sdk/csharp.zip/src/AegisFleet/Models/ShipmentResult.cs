using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// ShipmentResult object
/// </summary>
public record ShipmentResult
{
    /// <summary>
    /// True on success
    /// </summary>
    [JsonPropertyName("ok")]
    public required bool Ok { get; init; }

    /// <summary>
    /// True once the event is in the ledger
    /// </summary>
    [JsonPropertyName("sealed")]
    public required bool Sealed { get; init; }

    /// <summary>
    /// Agent run id
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("run_id")]
    public RunId? RunId { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
