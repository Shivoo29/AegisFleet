using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// KillSwitch object
/// </summary>
public record KillSwitch
{
    /// <summary>
    /// True when the kill switch is on
    /// </summary>
    [JsonPropertyName("on")]
    public required bool On { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
