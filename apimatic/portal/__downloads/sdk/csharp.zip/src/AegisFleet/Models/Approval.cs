using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;
using AegisFleet.Models.Enums;

namespace AegisFleet.Models;

/// <summary>
/// Approval object
/// </summary>
public record Approval
{
    /// <summary>
    /// Unique id
    /// </summary>
    [JsonPropertyName("id")]
    public required string Id { get; init; }

    /// <summary>
    /// Agent name: sentinel, defender, guardian or collector
    /// </summary>
    [JsonPropertyName("agent")]
    public required string Agent { get; init; }

    /// <summary>
    /// Gateway tool the agent called
    /// </summary>
    [JsonPropertyName("tool")]
    public required string Tool { get; init; }

    /// <summary>
    /// Tool arguments the agent asked the gateway to run
    /// </summary>
    [JsonPropertyName("args")]
    public required object Args { get; init; }

    /// <summary>
    /// Why
    /// </summary>
    [JsonPropertyName("reason")]
    public required string Reason { get; init; }

    /// <summary>
    /// One-line summary
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("summary")]
    public Summary1? Summary { get; init; }

    /// <summary>
    /// Amount in minor units (cents)
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("amount_cents")]
    public AmountCents? AmountCents { get; init; }

    /// <summary>
    /// ISO 4217 currency code
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("currency")]
    public Currency? Currency { get; init; }

    /// <summary>
    /// Current status
    /// </summary>
    [JsonPropertyName("status")]
    public required Status Status { get; init; }

    /// <summary>
    /// When it was created (ISO 8601)
    /// </summary>
    [JsonPropertyName("created_at")]
    public required DateTimeOffset CreatedAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
