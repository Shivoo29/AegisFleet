using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// LoginBody object
/// </summary>
public record LoginBody
{
    /// <summary>
    /// dev or judge
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("username")]
    public string? Username { get; init; } = "";

    /// <summary>
    /// Console password
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("password")]
    public string? Password { get; init; } = "";

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
