using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// HealthFactor object
/// </summary>
public record HealthFactor
{
    /// <summary>
    /// Factor name
    /// </summary>
    [JsonPropertyName("name")]
    public required string Name { get; init; }

    /// <summary>
    /// Measured value
    /// </summary>
    [JsonPropertyName("value")]
    public required object Value { get; init; }

    /// <summary>
    /// How this factor moves the score
    /// </summary>
    [JsonPropertyName("impact")]
    public required string Impact { get; init; }

    /// <summary>
    /// Free-text note
    /// </summary>
    [JsonPropertyName("note")]
    public required string Note { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
