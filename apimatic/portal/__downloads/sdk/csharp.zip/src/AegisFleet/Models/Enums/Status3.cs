using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// Current status
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Status3>))]
public sealed record Status3 : OpenStringEnum<Status3>
{
    private Status3(string value) : base(value)
    {
    }

    public static readonly Status3 Planned = new("planned");

    public static readonly Status3 Running = new("running");

    public static readonly Status3 Done = new("done");

    public static readonly Status3 Held = new("held");

    public static readonly Status3 Blocked = new("blocked");

    public static readonly Status3 Cancelled = new("cancelled");

    public TResult Match<TResult>(Func<TResult> onPlanned,
        Func<TResult> onRunning,
        Func<TResult> onDone,
        Func<TResult> onHeld,
        Func<TResult> onBlocked,
        Func<TResult> onCancelled,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Planned => onPlanned(),
            _ when this == Running => onRunning(),
            _ when this == Done => onDone(),
            _ when this == Held => onHeld(),
            _ when this == Blocked => onBlocked(),
            _ when this == Cancelled => onCancelled(),
            _ => otherwise(Value)
        };

    public void Match(Action onPlanned,
        Action onRunning,
        Action onDone,
        Action onHeld,
        Action onBlocked,
        Action onCancelled,
        Action<string> otherwise)
    {
        if (this == Planned) onPlanned();
        else if (this == Running) onRunning();
        else if (this == Done) onDone();
        else if (this == Held) onHeld();
        else if (this == Blocked) onBlocked();
        else if (this == Cancelled) onCancelled();
        else otherwise(Value);
    }
}
