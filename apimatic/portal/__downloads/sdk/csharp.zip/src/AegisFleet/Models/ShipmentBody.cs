using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// ShipmentBody object
/// </summary>
public record ShipmentBody
{
    /// <summary>
    /// Invoice id, e.g. INV-0007
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("invoice_id")]
    public InvoiceId? InvoiceId { get; init; }

    /// <summary>
    /// Carrier tracking number
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("tracking_number")]
    public TrackingNumber? TrackingNumber { get; init; }

    /// <summary>
    /// Shipping carrier, e.g. UPS
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("carrier")]
    public string? Carrier { get; init; } = "OTHER";

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
