using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;
using AegisFleet.Models.Enums;

namespace AegisFleet.Models;

/// <summary>
/// Decision object
/// </summary>
public record Decision
{
    /// <summary>
    /// allow, hold or deny
    /// </summary>
    [JsonPropertyName("outcome")]
    public required Outcome Outcome { get; init; }

    /// <summary>
    /// Why
    /// </summary>
    [JsonPropertyName("reason")]
    public required string Reason { get; init; }

    /// <summary>
    /// Id of the pending approval for this action
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("approval_id")]
    public ApprovalId? ApprovalId { get; init; }

    /// <summary>
    /// What the executed tool returned
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("result")]
    public Result? Result { get; init; }

    /// <summary>
    /// Ledger entry that seals this
    /// </summary>
    [JsonPropertyName("ledger_entry_id")]
    public required int LedgerEntryId { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
