using System.Collections.Generic;
using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// ValidationError object
/// </summary>
public record ValidationError
{
    /// <summary>
    /// Where the invalid value is
    /// </summary>
    [JsonPropertyName("loc")]
    public required IReadOnlyList<Loc> Loc { get; init; }

    /// <summary>
    /// Error message
    /// </summary>
    [JsonPropertyName("msg")]
    public required string Msg { get; init; }

    /// <summary>
    /// Error type
    /// </summary>
    [JsonPropertyName("type")]
    public required string Type { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
