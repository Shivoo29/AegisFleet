using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// Summary object
/// </summary>
public record Summary
{
    /// <summary>
    /// Total held for approval, in cents
    /// </summary>
    [JsonPropertyName("money_at_risk_cents")]
    public required int MoneyAtRiskCents { get; init; }

    /// <summary>
    /// ISO 4217 currency code
    /// </summary>
    [JsonPropertyName("currency")]
    public required string Currency { get; init; }

    /// <summary>
    /// Actions waiting for a human
    /// </summary>
    [JsonPropertyName("pending_approvals")]
    public required int PendingApprovals { get; init; }

    /// <summary>
    /// Number of open disputes
    /// </summary>
    [JsonPropertyName("open_disputes")]
    public required int OpenDisputes { get; init; }

    /// <summary>
    /// Number of overdue invoice events
    /// </summary>
    [JsonPropertyName("overdue_invoices")]
    public required int OverdueInvoices { get; init; }

    /// <summary>
    /// Account health score, 0-100
    /// </summary>
    [JsonPropertyName("health_score")]
    public required int HealthScore { get; init; }

    /// <summary>
    /// True when the kill switch blocks all agent actions
    /// </summary>
    [JsonPropertyName("kill_switch")]
    public required bool KillSwitch { get; init; }

    /// <summary>
    /// True when every ledger hash still matches
    /// </summary>
    [JsonPropertyName("chain_ok")]
    public required bool ChainOk { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
