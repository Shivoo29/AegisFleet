using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;
using AegisFleet.Models.Enums;

namespace AegisFleet.Models;

/// <summary>
/// Plan object
/// </summary>
public record Plan
{
    /// <summary>
    /// Unique id
    /// </summary>
    [JsonPropertyName("id")]
    public required string Id { get; init; }

    /// <summary>
    /// Agent name: sentinel, defender, guardian or collector
    /// </summary>
    [JsonPropertyName("agent")]
    public required string Agent { get; init; }

    /// <summary>
    /// Gateway tool the agent called
    /// </summary>
    [JsonPropertyName("tool")]
    public required string Tool { get; init; }

    /// <summary>
    /// Tool arguments the agent asked the gateway to run
    /// </summary>
    [JsonPropertyName("args")]
    public required object Args { get; init; }

    /// <summary>
    /// Why
    /// </summary>
    [JsonPropertyName("reason")]
    public required string Reason { get; init; }

    /// <summary>
    /// Title
    /// </summary>
    [JsonPropertyName("title")]
    public required string Title { get; init; }

    /// <summary>
    /// What this is about: an invoice, dispute or email id
    /// </summary>
    [JsonPropertyName("subject_id")]
    public required string SubjectId { get; init; }

    /// <summary>
    /// Due at
    /// </summary>
    [JsonPropertyName("due_at")]
    public required DateTimeOffset DueAt { get; init; }

    /// <summary>
    /// Current status
    /// </summary>
    [JsonPropertyName("status")]
    public required Status3 Status { get; init; }

    /// <summary>
    /// allow, hold or deny
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("outcome")]
    public Outcome1? Outcome { get; init; }

    /// <summary>
    /// When it was created (ISO 8601)
    /// </summary>
    [JsonPropertyName("created_at")]
    public required DateTimeOffset CreatedAt { get; init; }

    /// <summary>
    /// Updated at
    /// </summary>
    [JsonPropertyName("updated_at")]
    public required DateTimeOffset UpdatedAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
