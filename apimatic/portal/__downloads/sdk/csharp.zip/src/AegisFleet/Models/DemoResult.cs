using System.Text.Json.Serialization;
using AegisFleet.Core.Models;

namespace AegisFleet.Models;

/// <summary>
/// DemoResult object
/// </summary>
public record DemoResult
{
    /// <summary>
    /// True on success
    /// </summary>
    [JsonPropertyName("ok")]
    public required bool Ok { get; init; }

    /// <summary>
    /// What happened, in plain words, for the console toast
    /// </summary>
    [JsonPropertyName("message")]
    public required string Message { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
