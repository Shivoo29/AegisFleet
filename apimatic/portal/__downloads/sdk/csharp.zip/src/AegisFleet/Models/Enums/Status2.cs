using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// Current status
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Status2>))]
public sealed record Status2 : OpenStringEnum<Status2>
{
    private Status2(string value) : base(value)
    {
    }

    public static readonly Status2 Paid = new("paid");

    public static readonly Status2 Overdue = new("overdue");

    public static readonly Status2 Sent = new("sent");

    public TResult Match<TResult>(Func<TResult> onPaid,
        Func<TResult> onOverdue,
        Func<TResult> onSent,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Paid => onPaid(),
            _ when this == Overdue => onOverdue(),
            _ when this == Sent => onSent(),
            _ => otherwise(Value)
        };

    public void Match(Action onPaid, Action onOverdue, Action onSent, Action<string> otherwise)
    {
        if (this == Paid) onPaid();
        else if (this == Overdue) onOverdue();
        else if (this == Sent) onSent();
        else otherwise(Value);
    }
}
