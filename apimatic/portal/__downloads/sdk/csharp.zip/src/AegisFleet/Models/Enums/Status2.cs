using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// Current status
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Status2>))]
public sealed record Status2 : OpenStringEnum<Status2>
{
    private Status2(string value) : base(value)
    {
    }

    public static readonly Status2 Paid = new("paid");

    public static readonly Status2 Overdue = new("overdue");

    public static readonly Status2 Sent = new("sent");

    public static readonly Status2 Refunded = new("refunded");

    public TResult Match<TResult>(Func<TResult> onPaid,
        Func<TResult> onOverdue,
        Func<TResult> onSent,
        Func<TResult> onRefunded,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Paid => onPaid(),
            _ when this == Overdue => onOverdue(),
            _ when this == Sent => onSent(),
            _ when this == Refunded => onRefunded(),
            _ => otherwise(Value)
        };

    public void Match(Action onPaid, Action onOverdue, Action onSent, Action onRefunded, Action<string> otherwise)
    {
        if (this == Paid) onPaid();
        else if (this == Overdue) onOverdue();
        else if (this == Sent) onSent();
        else if (this == Refunded) onRefunded();
        else otherwise(Value);
    }
}
