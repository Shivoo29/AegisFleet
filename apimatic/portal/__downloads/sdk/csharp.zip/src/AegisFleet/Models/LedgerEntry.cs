using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.Enums;

namespace AegisFleet.Models;

/// <summary>
/// LedgerEntry object
/// </summary>
public record LedgerEntry
{
    /// <summary>
    /// Unique id
    /// </summary>
    [JsonPropertyName("id")]
    public required int Id { get; init; }

    /// <summary>
    /// Entry kind: event, decision, agent_step, approval or note
    /// </summary>
    [JsonPropertyName("kind")]
    public required Kind Kind { get; init; }

    /// <summary>
    /// What this is about: an invoice, dispute or email id
    /// </summary>
    [JsonPropertyName("subject_id")]
    public required string SubjectId { get; init; }

    /// <summary>
    /// One-line summary
    /// </summary>
    [JsonPropertyName("summary")]
    public required string Summary { get; init; }

    /// <summary>
    /// Sealed data for this entry
    /// </summary>
    [JsonPropertyName("payload")]
    public required object Payload { get; init; }

    /// <summary>
    /// Hash of the previous entry; empty for the first
    /// </summary>
    [JsonPropertyName("prev_hash")]
    public required string PrevHash { get; init; }

    /// <summary>
    /// SHA-256 of this entry plus the previous hash
    /// </summary>
    [JsonPropertyName("hash")]
    public required string Hash { get; init; }

    /// <summary>
    /// When it was created (ISO 8601)
    /// </summary>
    [JsonPropertyName("created_at")]
    public required DateTimeOffset CreatedAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
