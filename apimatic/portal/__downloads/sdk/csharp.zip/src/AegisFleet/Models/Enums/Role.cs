using System;
using System.Text.Json.Serialization;
using AegisFleet.Core.Enum;

namespace AegisFleet.Models.Enums;

/// <summary>
/// dev (seller) or judge
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Role>))]
public sealed record Role : OpenStringEnum<Role>
{
    private Role(string value) : base(value)
    {
    }

    public static readonly Role Dev = new("dev");

    public static readonly Role Judge = new("judge");

    public TResult Match<TResult>(Func<TResult> onDev, Func<TResult> onJudge, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Dev => onDev(),
            _ when this == Judge => onJudge(),
            _ => otherwise(Value)
        };

    public void Match(Action onDev, Action onJudge, Action<string> otherwise)
    {
        if (this == Dev) onDev();
        else if (this == Judge) onJudge();
        else otherwise(Value);
    }
}
