using System.Text.Json.Serialization;
using AegisFleet.Core.Models;
using AegisFleet.Models.AnyOf;

namespace AegisFleet.Models;

/// <summary>
/// ChainVerify object
/// </summary>
public record ChainVerify
{
    /// <summary>
    /// True on success
    /// </summary>
    [JsonPropertyName("ok")]
    public required bool Ok { get; init; }

    /// <summary>
    /// Number of ledger entries checked
    /// </summary>
    [JsonPropertyName("checked")]
    public required int Checked { get; init; }

    /// <summary>
    /// First ledger id whose hash no longer matches
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("broken_at")]
    public BrokenAt? BrokenAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
