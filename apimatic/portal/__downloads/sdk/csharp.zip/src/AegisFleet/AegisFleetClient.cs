using System.Net.Http;
using AegisFleet.Api;
using AegisFleet.Core;
using AegisFleet.Core.Configuration;
using AegisFleet.Core.Logging;
using AegisFleet.Core.Models;

namespace AegisFleet;

/// <summary>
/// Seller console API for AegisFleet: AI agents that guard a PayPal seller's payments, disputes, invoices and shipments. Agents never call PayPal directly; every action passes a guardrail gateway (kill switch, allowlist, caps, human approval) and is sealed into a hash-chained Proof Ledger.
/// <para>
/// Authenticate with HTTP Basic (<c>dev</c> or <c>judge</c>) or the session cookie set by <c>POST /api/login</c>.
/// </para>
/// </summary>
public sealed class AegisFleetClient
{
    private readonly RawClient _rawClient;
    private readonly Server _server;
    private readonly AuthSchemes _auth;

    public AegisFleetClient(HttpClient httpClient, AegisFleetClientOptions options)
    {
        _server = new Server(options.Environment, options.Server);
        var queryParameterFactory = new QueryParameterFactory([]);
        var templateParamsFactory = new TemplateParamsFactory([]);
        var urlFactory = new UriFactory(queryParameterFactory, templateParamsFactory);
        var httpStatusPolicy = new HttpStatusPolicy([]);
        var headersFactory = new HeadersFactory([
            new HeaderParam("User-Agent", "AegisFleetClient/1.0.0 CSharp"),
            new HeaderParam("X-APIMatic-Lang", "CSharp"),
            new HeaderParam("X-APIMatic-Package-Version", "1.0.0"),
            new HeaderParam("X-APIMatic-Gen-Version", "4.0.0"),
            new HeaderParam("X-APIMatic-OS", RuntimeEnvironment.Os),
            new HeaderParam("X-APIMatic-Runtime", RuntimeEnvironment.Runtime),
        ]);
        var resiliencePipelineFactory = new ResiliencePipelineFactory(options.Retry, options.TimeProvider);
        var httpLogger = new HttpLogger(
            options.Logging.WithEnvironmentDefaults("AEGIS_FLEET_LOG"),
            "AegisFleetClient",
            options.TimeProvider);
        var responseContexts = new ResponseContextFactory(options.TimeProvider, options.StreamReadTimeout);
        _rawClient =
            new RawClient(
                httpClient,
                urlFactory,
                httpStatusPolicy,
                headersFactory,
                resiliencePipelineFactory,
                httpLogger,
                options.Hooks,
                responseContexts);
        _auth = new AuthSchemes(options);
    }

    /// <summary>
    /// Summary, Proof Ledger, approvals, agent runs, disputes, invoices, health.
    /// </summary>
    public ConsoleApi ConsoleApi => field ??= new ConsoleApi(_rawClient, _server, _auth);

    /// <summary>
    /// One-click story beats for judges (demo mode only).
    /// </summary>
    public Demo Demo => field ??= new Demo(_rawClient, _server, _auth);

    /// <summary>
    /// Liveness probe.
    /// </summary>
    public Ops Ops => field ??= new Ops(_rawClient, _server);

    /// <summary>
    /// PayPal webhook receiver; signatures are verified with PayPal before routing.
    /// </summary>
    public WebhooksApi WebhooksApi => field ??= new WebhooksApi(_rawClient, _server);
}
