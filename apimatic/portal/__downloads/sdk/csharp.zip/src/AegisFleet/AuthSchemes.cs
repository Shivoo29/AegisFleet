using AegisFleet.Core.Authentication;
using AegisFleet.Core.Authentication.Basic;

namespace AegisFleet;

internal sealed class AuthSchemes
{
    public IAuthScheme HttpBasic { get; }

    public AuthSchemes(AegisFleetClientOptions options)
    {
        HttpBasic =
            BasicAuthScheme.Create(
                "HttpBasic",
                options.HttpBasicProvider,
                options.HttpBasic.WithEnvironmentDefaults(
                    "AEGIS_FLEET_HTTP_BASIC_USERNAME",
                    "AEGIS_FLEET_HTTP_BASIC_PASSWORD"));
    }
}
