using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using AegisFleet.Core.Hooks;
using AegisFleet.Core.Models;

namespace AegisFleet.Core;

public sealed record RequestOptions
{
    public LogLevel? LogLevel { get; init; }

    public IReadOnlyList<HeaderParam>? Headers { get; init; }

    public IReadOnlyList<SdkHook>? Hooks { get; init; }
}
