using System.Net.Http;

namespace AegisFleet.Core.Request;

internal interface IRequest
{
    HttpContent Get();

    bool CanRetry { get; }
}
