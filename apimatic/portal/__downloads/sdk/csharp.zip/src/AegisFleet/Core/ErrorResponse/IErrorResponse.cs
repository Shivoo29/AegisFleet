using System.Threading;
using System.Threading.Tasks;
using AegisFleet.Core.Models;

namespace AegisFleet.Core.ErrorResponse;

internal interface IErrorResponse<TError>
{
    Task<TError> Map(ResponseContext context, CancellationToken cancellationToken);
}
