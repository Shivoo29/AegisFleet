using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using AegisFleet.Core.ErrorResponse;
using AegisFleet.Core.Models;
using AegisFleet.Models;

namespace AegisFleet.Errors;

public sealed class PlansMoveError : ApiError
{
    private readonly Optional<HttpValidationError> _httpValidationErrorValue;

    private readonly Optional<RawError> _noContentValue;

    private PlansMoveError(Optional<HttpValidationError> httpValidationErrorValue,
        Optional<RawError> noContentValue,
        Optional<RawError> fallback) : base(fallback)
    {
        _httpValidationErrorValue = httpValidationErrorValue;
        _noContentValue = noContentValue;
    }

    private static PlansMoveError AsHttpValidationError(HttpValidationError value) =>
        new(Optional<HttpValidationError>.Some(value), default, default);

    private static PlansMoveError AsNoContent(RawError value) => new(default, Optional<RawError>.Some(value), default);

    private static PlansMoveError AsFallback(RawError value) => new(default, default, Optional<RawError>.Some(value));

    public bool TryGetHttpValidationError([NotNullWhen(true)] out HttpValidationError? value) =>
        _httpValidationErrorValue.TryGetValue(out value);

    public bool TryGetNoContent([NotNullWhen(true)] out RawError? value) => _noContentValue.TryGetValue(out value);

    public TResult Match<TResult>(Func<HttpValidationError, TResult> onHttpValidationError,
        Func<RawError, TResult> onNoContent,
        Func<RawError, TResult> otherwise) =>
        this switch
        {
            _ when TryGetHttpValidationError(out var httpValidationErrorValue) => onHttpValidationError(
                httpValidationErrorValue),
            _ when TryGetNoContent(out var noContentValue) => onNoContent(noContentValue),
            _ when TryGetRawError(out var fallback) => otherwise(fallback),
            _ => throw new InvalidOperationException($"{nameof(PlansMoveError)} holds no value.")
        };

    public void Match(Action<HttpValidationError> onHttpValidationError,
        Action<RawError> onNoContent,
        Action<RawError> otherwise)
    {
        if (TryGetHttpValidationError(out var httpValidationErrorValue)) onHttpValidationError(
            httpValidationErrorValue);
        else if (TryGetNoContent(out var noContentValue)) onNoContent(noContentValue);
        else if (TryGetRawError(out var fallback)) otherwise(fallback);
        else throw new InvalidOperationException($"{nameof(PlansMoveError)} holds no value.");
    }

    private static Task<PlansMoveError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            401 or 404 => response.RawBody().As(AsNoContent),
            422 => response.Json<HttpValidationError>().As(AsHttpValidationError),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<PlansMoveError> Response { get; } = new(Create);
}
