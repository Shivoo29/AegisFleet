using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using AegisFleet.Core;
using AegisFleet.Core.Authentication;
using AegisFleet.Core.ErrorResponse;
using AegisFleet.Core.Exceptions;
using AegisFleet.Core.Request;
using AegisFleet.Core.Response;

namespace AegisFleet.Api;

/// <summary>
/// Liveness probe.
/// </summary>
public sealed class Ops
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal Ops(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Healthz
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="object"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Liveness probe for Render and the keep-alive ping. No auth.
    /// </remarks>
    public Task<object> Healthz(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/healthz"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<object>(),
            RawErrorResponse.Instance,
            AuthScheme.None,
            requestOptions,
            cancellationToken);
}
