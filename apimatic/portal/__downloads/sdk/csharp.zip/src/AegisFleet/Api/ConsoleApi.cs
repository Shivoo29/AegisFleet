using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using AegisFleet.Core;
using AegisFleet.Core.Authentication;
using AegisFleet.Core.Exceptions;
using AegisFleet.Core.Models;
using AegisFleet.Core.Request;
using AegisFleet.Core.Response;
using AegisFleet.Errors;
using AegisFleet.Models;
using AegisFleet.Requests.ConsoleApi;

namespace AegisFleet.Api;

/// <summary>
/// Summary, Proof Ledger, approvals, agent runs, disputes, invoices, health.
/// </summary>
public sealed class ConsoleApi
{
    private readonly RawClient _rawClient;
    private readonly Server _server;
    private readonly AuthSchemes _auth;

    internal ConsoleApi(RawClient rawClient, Server server, AuthSchemes auth)
    {
        _rawClient = rawClient;
        _server = server;
        _auth = auth;
    }

    /// <summary>
    /// Approvals
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="IReadOnlyList{T}"/> of <see cref="Approval"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="ApprovalsError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Agent actions the gateway held for a human decision (over the money cap).
    /// </remarks>
    public Task<IReadOnlyList<Approval>> Approvals(ApprovalsRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/approvals"),
            [],
            [new Param("status", request.Status)],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<IReadOnlyList<Approval>>(),
            ApprovalsError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Decide Approval
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ApprovalResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="DecideApprovalError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Approve (the gateway then executes the held action) or reject it. Both are sealed.
    /// </remarks>
    public Task<ApprovalResult> DecideApproval(DecideApprovalRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/approvals/{approval_id}/{action}"),
            [new TemplateParam("approval_id", request.ApprovalId), new TemplateParam("action", request.Action)],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<ApprovalResult>(),
            DecideApprovalError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Dispute Detail
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DisputeDetail"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="DisputeDetailError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// One dispute with Defender's evidence pack and the pending approval to submit it.
    /// </remarks>
    public Task<DisputeDetail> DisputeDetail(DisputeDetailRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/disputes/{dispute_id}"),
            [new TemplateParam("dispute_id", request.DisputeId)],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<DisputeDetail>(),
            DisputeDetailError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Disputes
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="IReadOnlyList{T}"/> of <see cref="Dispute"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="DisputesError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Latest state of every PayPal dispute, newest first.
    /// </remarks>
    public Task<IReadOnlyList<Dispute>> Disputes(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/disputes"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<IReadOnlyList<Dispute>>(),
            DisputesError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Get Killswitch
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="KillSwitch"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="GetKillswitchError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Is the kill switch on?
    /// </remarks>
    public Task<KillSwitch> GetKillswitch(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/killswitch"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<KillSwitch>(),
            GetKillswitchError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Health
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Health"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="HealthError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Score and factors are recomputed from the ledger on every call, so a dispute that
    /// arrived after Guardian's last run still counts. Guardian's AI recommendations are
    /// reused only while the factors they were written for still hold.
    /// </remarks>
    public Task<Health> Health(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/health"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<Health>(),
            HealthError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Inbox
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="InboxVerdict"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="InboxError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Run Sentinel inline (a few seconds) so the console gets the verdict in one call.
    /// </remarks>
    public Task<InboxVerdict> Inbox(InboxRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/inbox"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<InboxVerdict>(),
            InboxError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Invoices
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="IReadOnlyList{T}"/> of <see cref="Invoice"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="InvoicesError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Invoices with paid/overdue status, risk, shipment and PayPal payment link.
    /// </remarks>
    public Task<IReadOnlyList<Invoice>> Invoices(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/invoices"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<IReadOnlyList<Invoice>>(),
            InvoicesError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Ledger
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="IReadOnlyList{T}"/> of <see cref="LedgerEntry"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="LedgerError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Proof Ledger entries, newest first. Each entry's hash covers the previous one.
    /// </remarks>
    public Task<IReadOnlyList<LedgerEntry>> Ledger(LedgerRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/ledger"),
            [],
            [
                new Param("kind", request.Kind),
                new Param("subject_id", request.SubjectId),
                new Param("limit", request.Limit),
            ],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<IReadOnlyList<LedgerEntry>>(),
            LedgerError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Ledger Verify
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ChainVerify"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="LedgerVerifyError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Recompute every hash in the chain and report the first entry that no longer matches.
    /// </remarks>
    public Task<ChainVerify> LedgerVerify(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/ledger/verify"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<ChainVerify>(),
            LedgerVerifyError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Login
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Me"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="LoginError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Check a username and password and set a 12-hour session cookie.
    /// </remarks>
    public Task<Me> Login(LoginRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/login"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<Me>(),
            LoginError.Response,
            AuthScheme.None,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Logout
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Ok"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="LogoutError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Clear the session cookie.
    /// </remarks>
    public Task<Ok> Logout(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/logout"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<Ok>(),
            LogoutError.Response,
            AuthScheme.None,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Mcp Link
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="object"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="McpLinkError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// A personal MCP URL (token inside, valid 14 days) for any AI client that only accepts a URL.
    /// </remarks>
    public Task<object> McpLink(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mcp/link"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<object>(),
            McpLinkError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Me
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Me"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="MeError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Who is logged in, and whether they are the seller (dev) or a read-mostly judge.
    /// </remarks>
    public Task<Me> Me(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/me"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<Me>(),
            MeError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Plans Cancel
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Ok"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="PlansCancelError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Seller cancels a planned action. Sealed in the ledger.
    /// </remarks>
    public Task<Ok> PlansCancel(PlansCancelRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/plans/{plan_id}/cancel"),
            [new TemplateParam("plan_id", request.PlanId)],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<Ok>(),
            PlansCancelError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Plans List
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="IReadOnlyList{T}"/> of <see cref="Plan"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="PlansListError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// What the agents have scheduled: planned, done, held, blocked and cancelled actions.
    /// </remarks>
    public Task<IReadOnlyList<Plan>> PlansList(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/plans"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<IReadOnlyList<Plan>>(),
            PlansListError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Plans Move
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Plan"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="PlansMoveError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Seller moves a planned action to a new time (drag on the Timeline). Sealed in the ledger.
    /// </remarks>
    public Task<Plan> PlansMove(PlansMoveRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/plans/{plan_id}"),
            [new TemplateParam("plan_id", request.PlanId)],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            new HttpMethod("PATCH"),
            JsonRequest.Create(request.Body),
            JsonResponse.Create<Plan>(),
            PlansMoveError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Post Killswitch
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="KillSwitch"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="PostKillswitchError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Turn the kill switch on or off. While on, the gateway denies every agent action.
    /// </remarks>
    public Task<KillSwitch> PostKillswitch(PostKillswitchRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/killswitch"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<KillSwitch>(),
            PostKillswitchError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Runs
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="IReadOnlyList{T}"/> of <see cref="AgentRun"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RunsError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Recent agent runs with their steps and structured output.
    /// </remarks>
    public Task<IReadOnlyList<AgentRun>> Runs(RunsRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/runs"),
            [],
            [new Param("limit", request.Limit)],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<IReadOnlyList<AgentRun>>(),
            RunsError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Shipments
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ShipmentResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="ShipmentsError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Seller adds tracking: store it, then fire shipment.created (sealed + routed to Guardian).
    /// </remarks>
    public Task<ShipmentResult> Shipments(ShipmentsRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/shipments"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<ShipmentResult>(),
            ShipmentsError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Summary
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Summary"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="SummaryError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Overview numbers: money waiting on approval, open disputes, overdue invoices, health, chain state.
    /// </remarks>
    public Task<Summary> Summary(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/summary"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<Summary>(),
            SummaryError.Response,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);
}
