using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using AegisFleet.Core;
using AegisFleet.Core.Authentication;
using AegisFleet.Core.ErrorResponse;
using AegisFleet.Core.Exceptions;
using AegisFleet.Core.Models;
using AegisFleet.Core.Request;
using AegisFleet.Core.Response;

namespace AegisFleet.Api;

/// <summary>
/// PayPal webhook receiver; signatures are verified with PayPal before routing.
/// </summary>
public sealed class WebhooksApi
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal WebhooksApi(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Paypal Webhook
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="object"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// PayPal calls this. The signature is verified with PayPal before the event is sealed and routed.
    /// </remarks>
    public Task<object> PaypalWebhook(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/webhooks/paypal"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<object>(),
            RawErrorResponse.Instance,
            AuthScheme.None,
            requestOptions,
            cancellationToken);
}
