using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using AegisFleet.Core;
using AegisFleet.Core.ErrorResponse;
using AegisFleet.Core.Exceptions;
using AegisFleet.Core.Models;
using AegisFleet.Core.Request;
using AegisFleet.Core.Response;
using AegisFleet.Models;

namespace AegisFleet.Api;

/// <summary>
/// One-click story beats for judges (demo mode only).
/// </summary>
public sealed class Demo
{
    private readonly RawClient _rawClient;
    private readonly Server _server;
    private readonly AuthSchemes _auth;

    internal Demo(RawClient rawClient, Server server, AuthSchemes auth)
    {
        _rawClient = rawClient;
        _server = server;
        _auth = auth;
    }

    /// <summary>
    /// Delivered
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Courier says the parcel arrived -&gt; Guardian updates tracking.
    /// </remarks>
    public Task<DemoResult> Delivered(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/delivered"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Demo Status
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="object"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// 200 when demo mode is on (404 otherwise).
    /// </remarks>
    public Task<object> DemoStatus(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/status"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<object>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Overdue
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// INV-0006 slips 9 days past due -&gt; Collector scores it and sends a capped, polite reminder.
    /// </remarks>
    public Task<DemoResult> Overdue(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/overdue"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Replay Injection
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// An email told an agent to refund. Sentinel isn't allowed to refund -&gt; gateway DENY, sealed.
    /// </remarks>
    public Task<DemoResult> ReplayInjection(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/replay_injection"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Reset
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Wipe everything, then replay Riya's story so the console never starts empty.
    /// </remarks>
    public Task<DemoResult> Reset(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/reset"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Sandbox Invoice
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Create a real invoice in the PayPal sandbox. Paying it fires a real, signed webhook.
    /// </remarks>
    public Task<DemoResult> SandboxInvoice(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/sandbox_invoice"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Sandbox Record Payment
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Backup for flaky sandbox checkout: record payment on the newest unpaid sandbox invoice.
    /// <para>
    /// PayPal then sends the same signed INVOICING.INVOICE.PAID webhook a buyer payment would.
    /// </para>
    /// </remarks>
    public Task<DemoResult> SandboxRecordPayment(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/sandbox_record_payment"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Scam Email
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Fake 'payment received' email: no verified payment in the ledger -&gt; Sentinel says scam.
    /// </remarks>
    public Task<DemoResult> ScamEmail(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/scam_email"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Tamper
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DemoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Edit one sealed entry behind the ledger's back -&gt; verify() points at it.
    /// </remarks>
    public Task<DemoResult> Tamper(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/demo/tamper"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            EmptyBody.Instance,
            JsonResponse.Create<DemoResult>(),
            RawErrorResponse.Instance,
            _auth.HttpBasic,
            requestOptions,
            cancellationToken);
}
