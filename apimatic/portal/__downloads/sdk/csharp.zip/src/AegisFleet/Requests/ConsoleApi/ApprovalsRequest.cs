namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the Approvals operation.
/// </summary>
public sealed record ApprovalsRequest
{
    /// <summary>
    /// Current status
    /// </summary>
    public string Status { get; init; } = "pending";
}
