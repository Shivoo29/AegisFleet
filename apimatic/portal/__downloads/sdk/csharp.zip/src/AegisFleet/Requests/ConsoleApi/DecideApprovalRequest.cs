using AegisFleet.Models.AnyOf;
using AegisFleet.Models.Enums;

namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the DecideApproval operation.
/// </summary>
public sealed record DecideApprovalRequest
{
    /// <summary>
    /// Id of the pending approval for this action
    /// </summary>
    public required string ApprovalId { get; init; }

    /// <summary>
    /// approve or reject
    /// </summary>
    public required ActionEnum Action { get; init; }

    public Body1? Body { get; init; }
}
