namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the DisputeDetail operation.
/// </summary>
public sealed record DisputeDetailRequest
{
    /// <summary>
    /// PayPal dispute id, e.g. PP-D-12345
    /// </summary>
    public required string DisputeId { get; init; }
}
