using AegisFleet.Models;

namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the PostKillswitch operation.
/// </summary>
public sealed record PostKillswitchRequest
{
    public required KillSwitchBody Body { get; init; }
}
