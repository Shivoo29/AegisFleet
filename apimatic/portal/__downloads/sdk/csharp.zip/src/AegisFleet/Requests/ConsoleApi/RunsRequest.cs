namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the Runs operation.
/// </summary>
public sealed record RunsRequest
{
    /// <summary>
    /// Maximum number of items to return
    /// </summary>
    public int Limit { get; init; } = 20;
}
