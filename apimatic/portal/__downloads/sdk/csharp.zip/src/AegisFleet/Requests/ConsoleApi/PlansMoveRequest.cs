using AegisFleet.Models;

namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the PlansMove operation.
/// </summary>
public sealed record PlansMoveRequest
{
    /// <summary>
    /// plan_id
    /// </summary>
    public required string PlanId { get; init; }

    public required PlanMove Body { get; init; }
}
