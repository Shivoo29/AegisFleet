namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the PlansCancel operation.
/// </summary>
public sealed record PlansCancelRequest
{
    /// <summary>
    /// plan_id
    /// </summary>
    public required string PlanId { get; init; }
}
