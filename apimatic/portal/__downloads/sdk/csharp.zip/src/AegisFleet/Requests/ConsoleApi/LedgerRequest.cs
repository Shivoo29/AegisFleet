using AegisFleet.Models.AnyOf;

namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the Ledger operation.
/// </summary>
public sealed record LedgerRequest
{
    /// <summary>
    /// Entry kind: event, decision, agent_step, approval or note
    /// </summary>
    public Kind1? Kind { get; init; }

    /// <summary>
    /// What this is about: an invoice, dispute or email id
    /// </summary>
    public SubjectIdModel? SubjectId { get; init; }

    /// <summary>
    /// Maximum number of items to return
    /// </summary>
    public int Limit { get; init; } = 100;
}
