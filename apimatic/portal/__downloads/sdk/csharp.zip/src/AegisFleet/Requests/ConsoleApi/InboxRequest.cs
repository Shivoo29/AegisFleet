using AegisFleet.Models;

namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the Inbox operation.
/// </summary>
public sealed record InboxRequest
{
    public required InboxEmail Body { get; init; }
}
