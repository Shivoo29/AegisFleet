using AegisFleet.Models;

namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the Shipments operation.
/// </summary>
public sealed record ShipmentsRequest
{
    public required ShipmentBody Body { get; init; }
}
