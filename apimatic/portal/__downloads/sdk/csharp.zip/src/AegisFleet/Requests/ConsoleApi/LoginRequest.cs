using AegisFleet.Models;

namespace AegisFleet.Requests.ConsoleApi;

/// <summary>
/// The inputs of the Login operation.
/// </summary>
public sealed record LoginRequest
{
    public required LoginBody Body { get; init; }
}
