using AegisFleet.Servers;

namespace AegisFleet;

public class ServerOptions
{
    public DefaultOptions Default { get; set; } = new();
}
